library(nimble)

######################################################
#' DEFINITIONS:
#' 
#' OBSERVED DATA:
#' To  the number of capture–recapture occasions.
#' G   the number of batch-marked release groups; G ≤ T.
#' Sg  the number of individuals sampled at sampling occasion g; g = 1, 2, . . . , G.
#' Rg  the number of individuals marked and released at sampling occasion g from batch group g; g = 1, 2, . . . , G. We condition on the {Rg} when we form the likelihood for marked individuals.
#' mgt the number of individuals from batch group g recaptured at recapture occasion t; g = 1, 2, . . . , G, t = g + 1, . . . , T.
#' ut  the number of individuals captured at sampling occasion t that were not marked; t = 1, . . . , T.
#' lt the number of individuals lost at sampling occasion t; t = 2, . . . , T. ℓt = ut − Rt.
#'
#' LATENT VARIABLES:
#' Mgt the number of individuals present at occasion t from marked group g; g = 1, 2, . . . , G, t = g + 1, . . . , T.
#' dgt the number of individuals from marked group g that die at sampling occasion t. 
#' 
#' PARAMETERS:
#' phi survival
#' p   capture probability
#' 
######################################################

################################################################
# SETTING UP TEST DATA
# dipper data from marked
library(marked)
data(dipper)

ch = dipper$ch
h = matrix(NA, nrow=length(ch), ncol=length(unlist(strsplit(ch[1], split = ""))))
for(i in 1:length(ch)) {
  chi = unlist(strsplit(ch[i], split = ""))
  for(j in 1:length(chi)) {
    h[i,j] = as.integer(chi[j])
  }
}

# h=capture history: 1 row per individual, 1 column per sampling occasion
#h = matrix(c(1,0,0,1,0,0,0,0,
#             0,0,1,1,1,0,0,0,
#             0,1,0,1,0,0,0,0,
#             0,0,0,0,1,1,0,0,
#             1,0,1,1,0,0,1,0), nrow=5, byrow = T)

# NOTE: first capture == group number g
# f=first capture per individual:
get.first <- function(x) min(which(x!=0))
f <- apply(h, 1, get.first)

To = dim(h)[2]
G  = max(f)
Sg = numeric(G)
mgt = array(0, dim=c(G,To))
Rg = numeric(To)
lt = numeric(To)
ut = numeric(To)
for(g in 1:G) {
  # total individuals observed at group g
  Sg[g] = sum(h[,g])

  # number of individuals from group g recaptured at recapture occasion t
  mgt[g,] = colSums(h[which(f==g),])
  mgt[g,g] = 0
}

for(t in 1:To) {
  # individuals lost on capture, zero here, otherwise replace with observed data
  lt[t] = 0
  
  # individuals captured at sampling occasion t that were not marked: total observed - total marked among observed
  ut[t] = sum(h[,t]) - sum(mgt[,t])
  
  # individuals marked and released at group g (here, all individuals are marked and released, otherwise replace with observed data)
  if(t <= G) {
    Rg[t] = ut[t] - lt[t]
  }
}
# DONE SETTING UP TEST DATA
################################################################


#NIMBLE code for the Marked Likelihood
nimLm <- nimbleCode({ 
  ## Priors and constraints
  for (g in 1:G){
    Mgt[g,g] <- Rg[g] # initial marked populations
    
    for (t in 1:To){
      phi[g,t] <- mean.phi
      p[g,t]   <- mean.p
    } #t
  } #i
  mean.phi ~ dunif(0, 1) # Prior for mean survival
  mean.p   ~ dunif(0, 1)  # Prior for mean recapture
  
  ## Likelihood
  for (g in 1:G){
    for (t in (g+1):To) {
      # State process
      Mgt[g,t] ~ dbinom(phi[g,t], Mgt[g,t-1]) # survival with prob phi_gt; Note: Xg1 == Rg
      #dgt[g,t] <- Xgt[g,t-1] - Xgt[g,t]      # deaths are those that did not survive
      
      # Observation process
      mgt[g,t] ~ dbinom(p[g,t], Mgt[g,t])
    } # t
  } # g
})

#Set up the model
#Assign values to the constants in the model, provide data, initialize the random variables, and then create the model.
LmConsts <- list(To  = To,
                 G   = G,
                 Sg  = Sg,
                 Rg  = Rg,
                 mgt = mgt,
                 lt  = lt,
                 ut  = ut)

# Initial values
Mgt_init = mgt * NA
Mgt_init[,1] = 2 * mgt[,1]
LmInits <- list(Mgt = Mgt_init, 
                #dgt = 0 * rgt,
                mean.phi = 0.7, 
                mean.p   = 0.5, 
                p   = matrix(0.5, nrow=G, ncol=To), 
                phi = matrix(0.5, nrow=G, ncol=To))

# Parameters monitored
parameters <- c("mean.phi", "mean.p")
parameters2 <- c("mean.phi", "mean.p", "Mgt")

#Create the model
Lm_mod <- nimbleModel(code = nimLm, name = "Lm", constants = LmConsts, inits = LmInits)

#Compile the model in C++
CLm_mod <- compileNimble(Lm_mod)

#Run the MCEM algorithm provided by NIMBLE
box <- list( list(c("mean.phi", "mean.p"), c(0, 1))) ## Constraints for the parameters
LmMCMC <- buildMCMC(CLm_mod, boxConstraints = box, monitors = parameters, monitors2 = parameters2, enableWAIC = TRUE)
CLmMCMC <- compileNimble(LmMCMC)

LmMCMC_samples <- runMCMC(CLmMCMC, nburnin = 10000, niter = 12000, WAIC=TRUE)
LmMCMC_samples$WAIC

# MCMC parameter plots
median(LmMCMC_samples$samples[ , 'mean.phi'])
median(LmMCMC_samples$samples[ , 'mean.p'])

library(ggplot2)
posterior <- ggplot(as.data.frame(LmMCMC_samples$samples), aes(x = mean.p, y = mean.phi)) +
  geom_point(alpha=0.2, colour="orange1") +
  stat_density2d(aes(colour = ..level..), size=1.2) +
  # parameter initial values (black X)
  geom_point(aes(x=LmInits$mean.p, y=LmInits$mean.phi), shape=4, stroke=2) +
  # posterior means (blue X)
  geom_point(aes(x=mean(LmMCMC_samples$samples[ , 'mean.p']), y=mean(LmMCMC_samples$samples[ , 'mean.phi'])), shape=4, stroke=2, colour="blue") +
  # posterior medians (red X)
  geom_point(aes(x=median(LmMCMC_samples$samples[ , 'mean.p']), y=median(LmMCMC_samples$samples[ , 'mean.phi'])), shape=4, stroke=2, colour="red") +
  theme_classic() +
  xlab(expression(widehat(p))) +
  ylab(expression(widehat(phi)))

posterior
